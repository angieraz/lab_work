package Droid;

import java.util.Random;

class Attacker extends Droid {
    public Attacker(String name) {
        super(name, 100, 35, 40, 30, 25);
        Random random = new Random();
        setAttack(random.nextInt(getDamage() - getMinAttack() + 1) + getMinAttack());
    }

    @Override
    public void outputDroidInfo() {
        super.outputDroidInfo();
        System.out.println("Тип дроїда: атакувальник");
    }

    @Override
    public void attack(Droid targetDroid) {
        int damage = getAttack();
        int newProtection = targetDroid.getProtection() - (int) (damage / 3.0);
        targetDroid.setProtection(Math.max(0, newProtection)); // Захист не може бути від'ємним
        targetDroid.health -= damage;
        System.out.println(this.name + " атакує " + targetDroid.name + " і завдає " + getAttack() + " пошкоджень.");
        System.out.println(targetDroid.name + " захист зменшено до " + targetDroid.getProtection());

        String result = this.name + " атакує " + targetDroid.name + " і завдає " + getAttack() + " пошкоджень." +
                "\n"+ targetDroid.name + " захист зменшено до " + targetDroid.getProtection();
        BattleResults.saveBattleResultsToFile(droidList, result);

    }
}
