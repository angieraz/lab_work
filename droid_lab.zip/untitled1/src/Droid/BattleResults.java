package Droid;
import java.util.List;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;

public class BattleResults {
    public static void saveBattleResultsToFile(List<Droid> droidList, String result) {
        try {
            File file = new File("D:\\battle_results.txt");
            FileWriter fileWriter = new FileWriter(file, true); // Append mode (second argument is true)
            BufferedWriter writer = new BufferedWriter(fileWriter);

            writer.write(result);
            writer.newLine();

            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void printBattleResultsFromFile() {
        System.out.println("Гру записано! Бажаєте відтворити бій?");
        System.out.println("Введіть 1 якщо так");
        Scanner scanner = new Scanner(System.in);

        int yes = scanner.nextInt();
        if(yes == 1){
            try {
                BufferedReader reader = new BufferedReader(new FileReader("D:\\battle_results.txt"));
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }
}
