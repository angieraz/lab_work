package Droid;
import java.util.ArrayList;
import java.util.Random;

class Magician extends Droid {
    private ArrayList<Droid> droidList;
    public Magician(String name) {
        super(name, 200, 35, 0, 25, 20);
        Random random = new Random();
        setAttack(random.nextInt(getDamage() - getMinAttack() + 1) + getMinAttack());
    }

    @Override
    public void attack(Droid targetDroid) {
        if (targetDroid instanceof Knight) {
            Knight knight = (Knight) targetDroid;
            System.out.println("Маг " + this.name + " викликає закляття і знижує здоров'я " + targetDroid.name + " на 0.1");
            knight.setHealth((int)(knight.getHealth() * 0.1));

            targetDroid.setHealth(targetDroid.getHealth() - getAttack());

            System.out.println("Завдано " + getAttack() + " пошкоджень");

            String result = "Маг " + this.name + " викликає закляття і знижує здоров'я " + targetDroid.name + " на 0.1" +
                    "Завдано " + getAttack() + " пошкоджень";
            BattleResults.saveBattleResultsToFile(droidList, result);

        } else {
            System.out.println("Закляття мага безсильні, він проводить звичайну атаку");
            System.out.println(this.name + " атакує " + targetDroid.name + " і наносить " + getAttack() + " пошкоджень");
            targetDroid.setHealth(targetDroid.getHealth() - getAttack());

            String result = "Закляття мага безсильні, він проводить звичайну атаку" +
                    this.name + " атакує " + targetDroid.name + " і наносить " + getAttack() + " пошкоджень";
            BattleResults.saveBattleResultsToFile(droidList, result);
        }
    }

    @Override
    public void outputDroidInfo() {
        super.outputDroidInfo();
        System.out.println("Тип дроїда: маг");
    }
}
