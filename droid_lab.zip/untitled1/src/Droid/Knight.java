package Droid;

import java.util.Random;

class Knight extends Droid {

    public Knight(String name) {
        super(name, 300, 20, 80, 15, 17);
        Random random = new Random();
        setAttack(random.nextInt(getDamage() - getMinAttack() + 1) + getMinAttack());
    }

    @Override
    public void outputDroidInfo() {
        super.outputDroidInfo();
        System.out.println("Тип дроїда: рицар");
    }

    @Override
    public void attack(Droid targetDroid) {
        super.attack(targetDroid);

        System.out.println(this.name + " атакує " + targetDroid.name + " і завдає " + getAttack() + " пошкоджень.");

        String result = this.name + " атакує " + targetDroid.name + " і завдає " + getAttack() + " пошкоджень.";
        BattleResults.saveBattleResultsToFile(droidList, result);

        targetDroid.health -= getAttack();
    }
}