package Droid;

import java.util.Random;

class Archer extends Droid { // дроїд стрілок
    int arrows;
    public Archer(String name, int arrows) {
        super(name, 150, 30, 30, 20, 20);
        this.arrows = arrows;
        Random random = new Random();
        setAttack(random.nextInt(getDamage() - getMinAttack() + 1) + getMinAttack());
    }
    @Override
    public void outputDroidInfo() {
        super.outputDroidInfo();
        System.out.println("Стріли: " + arrows);
        System.out.println("Тип дроїда: стрілець");
    }

    @Override
    public void attack(Droid targetDroid) {
        super.attack(targetDroid);

        if (arrows > 0) {
            Random random = new Random();
            int numOfArrows = random.nextInt(2) + 1;
            int atc = getAttack();
            arrows--;

            if (numOfArrows == 2) {
                System.out.println("\nДроїд " + this.name + " атакує і йому посміхається вдача. ");
                System.out.println("Дві стріли попадають в " + targetDroid.name +" і завдають " + atc*2 + " пошкоджень.");
                targetDroid.health -= atc*2;

                String result = "\nДроїд " + this.name + " атакує і йому посміхається вдача. " +
                        "\nДві стріли попадають в " + targetDroid.name +" і завдають " + atc*2 + " пошкоджень. ";
                BattleResults.saveBattleResultsToFile(droidList, result);

            } else {
                System.out.println("Дроїд " + this.name + " атакує " + targetDroid.name + " стрілою, але раз промахнувся.");
                System.out.println("Завдано " + atc + " пошкоджень");
                targetDroid.health -= atc;

                String result = "Дроїд " + this.name + " атакує " + targetDroid.name + " стрілою, але раз промахнувся." +
                        "\nЗавдано " + atc + " пошкоджень ";
                BattleResults.saveBattleResultsToFile(droidList, result);
            }
            arrows= arrows-2;
        } else {
            System.out.println("Стріли закінчилися. Атака понизилася.");

            String result = "Стріли закінчилися. Атака понизилася.";
            BattleResults.saveBattleResultsToFile(droidList, result);

            this.arrows = 0;
            int atc = 5;
            targetDroid.health -= atc;
            System.out.println("Дроїд " + this.name + " атакує " + targetDroid.name + " і завдає " + atc + " пошкоджень.");

            result = "Дроїд " + this.name + " атакує " + targetDroid.name + " і завдає " + atc + " пошкоджень.";
            BattleResults.saveBattleResultsToFile(droidList, result);
        }

    }

}