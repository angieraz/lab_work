package Droid;

import java.util.List;

public class Droid {
    public String name;
    int health;
    private int damage;
    private int protection;
    private int attack;
    private int minAttack;
    protected List<Droid> droidList;

    public Droid(String name, int health, int damage, int protection, int attack, int minAttack) {
        this.name = name;
        this.health = health;
        this.damage = damage;
        this.protection = protection;
        this.attack = attack;
        this.minAttack = minAttack;
    }

    public void outputDroidInfo() {
        System.out.println("Ім'я дроїда: " + name);
        System.out.println("Кількість здоров'я: " + health);
        System.out.println("Атака: " + damage);
        System.out.println("Захист: " + protection);
    }

    public void attack(Droid targetDroid) {

        if (this.health < 0) {
            this.health = 0;
        }
        if (targetDroid.health < 0) {
            targetDroid.health = 0;
        }

        System.out.println("Здоров'я " + targetDroid.name + " : " + targetDroid.health);
        System.out.println("Здоров'я " + this.name + " : " + this.health);

        String result = "Здоров'я " + targetDroid.name + " : " + targetDroid.health +
                "\n Здоров'я " + this.name + " : " + this.health;

        BattleResults.saveBattleResultsToFile(droidList, result);
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getProtection() {
        return protection;
    }

    public void setProtection(int protection) {
        this.protection = protection;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getMinAttack() {
        return minAttack;
    }

    public void setMinAttack(int minAttack) {
        this.minAttack = minAttack;
    }
}
