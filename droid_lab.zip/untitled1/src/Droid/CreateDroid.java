package Droid;
import java.util.Scanner;
import java.util.ArrayList;

public class CreateDroid {
    public void CreateDroidType(ArrayList<Droid> droidList) {
        Scanner newObj = new Scanner(System.in);

            System.out.println("Оберіть тип дроїда для створення: \n" +
                    "1: дроїд-рицар - багато захисту і здоров'я, але низька атака \n" +
                    "2: дроїд-маг - сильно б'є, непогане здоров'я, але захист відсутній \n" +
                    "3: дроїд-стрілець - стріляє двічі при удачі, але низькі здоров'я та захист \n" +
                    "4: дроїд-атакувальник - має високу атаку та захист, але мало здоров'я \n");
            do {
            int numOfDroidType = newObj.nextInt();
            Droid newDroid = null;
            String name;

            System.out.println("Введіть ім'я дроїда: ");
            name = newObj.next();

            String droidType = "";

            switch (numOfDroidType) {
                case 1:
                    newDroid = new Knight(name);
                    droidType = "дроїд-рицар";
                    break;
                case 2:
                    newDroid = new Magician(name);
                    droidType = "дроїд-маг";
                    break;
                case 3:
                    newDroid = new Archer(name, 20);
                    droidType = "дроїд-стрілець";
                    break;
                case 4:
                    newDroid = new Attacker(name);
                    droidType = "дроїд-атакувальник";
                    break;
                default:
                    System.out.println("Помилка. Неправильне введене число.");
            }
            if (newDroid != null) {
                droidList.add(newDroid); // Add the created droid to the list
                System.out.println("Створено новий дроїд! Тип: " + droidType + ", Ім'я: " + name);

                System.out.println("\nБажаєте створити ще одного дроїда? Введіть 1");
                int choice2 = newObj.nextInt();
                if (choice2 != 1) {
                    break;
                }
                else {
                    System.out.println("Введіть тип дроїда для створення: ");
                }
            }
        } while (true);
    }

}
