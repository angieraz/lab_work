package Droid;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
public class BattleDroid {

    public static void displayDroidList(List<Droid> droidList) {
        System.out.println("Список створених дроїдів:");
        for (int i = 0; i < droidList.size(); i++) {
            Droid droid = droidList.get(i);
            System.out.println("\nДроїд номер " + (i + 1) + ": ");
            droid.outputDroidInfo();
        }
    }

    public static void battleOneOnOne(List<Droid> droidList) {
        if (droidList.size() < 2) {
            System.out.println("Потрібно мати щонайменше два дроїди для битви.");
            return;
        }

        System.out.println("Оберіть двох дроїдів для битви:");
        Scanner scanner = new Scanner(System.in);

        int indexDroid1;
        int indexDroid2;
        boolean validSelection = false;

        do {
            indexDroid1 = scanner.nextInt();
            indexDroid2 = scanner.nextInt();
            indexDroid1 -=1;
            indexDroid2 -=1;
            if (indexDroid1 < 0 || indexDroid1 >= droidList.size() || indexDroid2 < 0 || indexDroid2 >= droidList.size()) {
                System.out.println("Невірний вибір дроїдів. Спробуйте ще раз.");
            } else {
                validSelection = true;
            }
        } while (!validSelection);

        Droid droid1 = droidList.get(indexDroid1);
        Droid droid2 = droidList.get(indexDroid2);

        System.out.println("Починається бій між " + droid1.name + " і " + droid2.name + "!");
        System.out.println(" ヽ(•̀ω•́ )ゝ✧ ");

        String result = "Починається бій між " + droid1.name + " і " + droid2.name + "!";
        BattleResults.saveBattleResultsToFile(droidList, result);

        while (droid1.getHealth() > 0 && droid2.getHealth() > 0) {
                droid1.attack(droid2);

            if (droid2.getHealth() <= 0) {
                System.out.println(droid1.name + " переміг " + droid2.name + "!");

                result = droid1.name + " переміг " + droid2.name + "!";
                BattleResults.saveBattleResultsToFile(droidList, result);

                droidList.remove(indexDroid2);
                indexDroid1 = droidList.indexOf(droid1);
                break;
            }
                droid2.attack(droid1);

            if (droid1.getHealth() <= 0) {
                System.out.println(droid2.name + " переміг " + droid1.name + "!");

                result = droid2.name + " переміг " + droid1.name + "!";
                BattleResults.saveBattleResultsToFile(droidList, result);

                droidList.remove(indexDroid1);
                break;
            }
        }
    }

    public static void battleTeams(List<Droid> droidList) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Скільки дроїдів у команді 1?");
        int team1Count = scanner.nextInt();
        System.out.println("Скільки дроїдів у команді 2?");
        int team2Count = scanner.nextInt();

        if (team1Count + team2Count > droidList.size()) {
            System.out.println("Недостатньо дроїдів для битви.");
            return;
        }
        if (team1Count <= 0 || team2Count <= 0) {
            System.out.println("Кількість дроїдів у команді повинна бути більше 0.");
            return;
        }

        if (team1Count > droidList.size() || team2Count > droidList.size()) {
            System.out.println("Недостатньо дроїдів для битви.");
            return;
        }

        List<Droid> team1 = new ArrayList<>();
        List<Droid> team2 = new ArrayList<>();

        for (int i = 0; i < team1Count; i++) {
            System.out.println("Виберіть дроїда для команди 1 (введіть номер зі списку):");
            displayDroidList(droidList);
            int selection = scanner.nextInt();
            team1.add(droidList.get(selection - 1));
        }

        for (int i = 0; i < team2Count; i++) {
            System.out.println("Виберіть дроїда для команди 2 (введіть номер зі списку):");
            displayDroidList(droidList);
            int selection = scanner.nextInt();
            team2.add(droidList.get(selection - 1));
        }

        System.out.println("Битва починається!");

        String result = "Битва починається!";
        BattleResults.saveBattleResultsToFile(droidList, result);

        int team1Score = 0;
        int team2Score = 0;

        for (int i = 0; i < Math.min(team1Count, team2Count); i++) {
            Droid droid1 = team1.get(i);
            Droid droid2 = team2.get(i);

            battleOneOnOne(droidList);

            if (droid1.getHealth() > 0) {
                team1Score++;
            } else if (droid2.getHealth() > 0) {
                team2Score++;
            }
        }

        if (team1Score > team2Score) {
            System.out.println("Команда 1 перемогла!");

            result = "Команда 1 перемогла!";
            BattleResults.saveBattleResultsToFile(droidList, result);
        } else  {
            System.out.println("Команда 2 перемогла!");

            result = "Команда 2 перемогла!";
            BattleResults.saveBattleResultsToFile(droidList, result);
        }
    }
}
