import java.util.ArrayList;
import java.util.Scanner;
import Droid.CreateDroid;
import Droid.BattleDroid;
import Droid.BattleResults;
import Droid.Droid;

class Main {

    public static void main(String[] args) {
        ArrayList<Droid> droidList = new ArrayList<>();
        CreateDroid createDroid = new CreateDroid();

        Scanner scanner = new Scanner(System.in);
        System.out.println("      ＿＿＿＿＿＿＿＿＿＿＿");
        System.out.println("     ∥    Вітаю у грі!  ∥");
        System.out.println("     ∥     Ось що ви    ∥");
        System.out.println("     ∥  можете зробити: ∥");
        System.out.println("     ∥＿＿＿＿＿＿＿＿＿＿＿");
        System.out.println(" ∧＿∧∥");
        System.out.println("(`･ω･∥");
        System.out.println("丶　つ０");
        System.out.println("しーＪ");

        while (true) {
            System.out.println("\n1: Створити нового дроїда \n" +
                    "2: Показати список дроїдів \n" +
                    "3: Запустити бій 1 на 1 \n" +
                    "4: Запустити бій команд \n" +
                    "5: Записати проведений бій у файл \n" +
                    "0: Вийти \n");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    createDroid.CreateDroidType(droidList);
                    break;
                case 2:
                    BattleDroid.displayDroidList(droidList);
                    break;
                case 3:
                    BattleDroid.battleOneOnOne(droidList);
                    break;
                case 4:
                    BattleDroid.battleTeams(droidList);
                    break;
                case 5:
                    BattleResults.printBattleResultsFromFile();
                    break;
                case 0:
                    System.out.println("Дякую за гру!");
                    System.out.println("〃 ∩     ◜◝   - -   ◜◝     ");
                    System.out.println("  ⊂   ⌒ (   。・ ㉨ ・  )");
                    System.out.println("       ヽ  _ つ＿/￣￣￣/");
                    System.out.println("             ＼/＿＿＿/");
                    return;
                default:
                    System.out.println("Невірний вибір ૮₍⇀‸↼‶₎ა  ");
                    System.out.println("Спробуйте ще раз.");
            }
        }
    }
}
