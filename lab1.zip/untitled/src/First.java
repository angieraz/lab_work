import java.util.Scanner;
/**
 * Клас, який містить реалізацію чисел Люка та їхню суму.
 */
public class First {
    /**
     * Обчислює перші n чисел Люка та зберігає їх у масиві res.
     *
     * @param numb Кількість чисел Люка, які потрібно обчислити.
     * @return res  Масив для зберігання обчислених чисел Люка.
     */
    public static int[] lucas(int numb){
        int[] res = new int[numb];
        int a =2, b =1;
        res[0] =a;
        res[1] = b;
        for(int i = 0; i < numb-2; i++){
           int c = res[i] + res[i+1];
            res[i+2]= c;
        }
        return res;
    }

    /**
     * Обчислює суму чисел в масиві.
     *
     * @param res Масив, суму елементів якого потрібно знайти.
     * @return Сума чисел в масиві.
     */
    public static int sum(int[] res){
        int sum = 0;
        for (int number : res) {
            sum += number;
        }
        return sum;
    }

    /**
     * Головний метод програми, який обчислює та виводить числа Люка та їхню суму.
     *
     * @param args Аргументи командного рядка (не використовуються в цьому випадку).
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введіть кількість перших чисел Люка: ");
        int nNumber = scanner.nextInt();

        int[] numbers = lucas(nNumber);

        System.out.println("Перші " + nNumber + " чисел Люка: ");
        for (int number : numbers) {
            System.out.print(number);
            System.out.print(" ");
        }

        System.out.print("\n");
        int sum;
        sum = sum(numbers);
        System.out.println("Сума чисел: " + sum);
    }
}
