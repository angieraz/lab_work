package src3;

import java.util.Date;

public class Student {
    //id, Прізвище, Ім'я, По батькові, Дата народження,
    //Адреса, Телефон, Факультет, Курс, Група
    private int id;
    private String surname; //Прізвище
    private String firstName; //Ім'я
    private String patName; //По батькові
    private int birthDay; //Дата народження
    private int birthMonth; //Дата народження
    private int birthYear; //Дата народження
    private String address;
    private long phoneNumber;
    private String faculty;
    private int course;
    private String group;

    // Конструктор з параметрами
    public Student(int id, String surname, String firstName, String patName, int birthDay,
                   int birthMonth, int birthYear, String address,
                   long phoneNumber, String faculty, int course, String group) {
        this.id = id;
        this.surname = surname;
        this.firstName = firstName;
        this.patName = patName;
        this.birthDay = birthDay;
        this.birthMonth = birthMonth;
        this.birthYear = birthYear;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.faculty = faculty;
        this.course = course;
        this.group = group;
    }

    // Геттери і сеттери
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getPatName() {
        return patName;
    }

    public void setPatName(String patName) {
        this.patName = patName;
    }

    public int getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(int birthDay) {
        this.birthDay = birthDay;
    }

    public int getBirthMonth() {
        return birthMonth;
    }

    public void setBirthMonth(int birthMonth) {
        this.birthMonth = birthMonth;
    }

    public int getBirthYear() {
        return birthYear;
    }

    public void setBirthYear(int birthYear) {
        this.birthYear = birthYear;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public int getCourse() {
        return course;
    }

    public void setCourse(int course) {
        this.course = course;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    // Метод toString() для представлення об'єкта у вигляді рядка

    @Override //перевизначає метод з батьківського класу
    public String toString() {
        return "Student {" +
                "id=" + id +
                ", surname='" + surname + '\'' +
                ", firstName='" + firstName + '\'' +
                ", patName='" + patName + '\'' +
                ", birthDate=" + birthDay + "." + birthMonth + "." + birthYear + "." +
                ", address='" + address + '\'' +
                ", phoneNumber=" + phoneNumber +
                ", faculty='" + faculty + '\'' +
                ", course=" + course +
                ", group='" + group + '\'' +
                '}';
    }
}