package src2;
import src3.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введіть кількість студентів: ");
        int number = scanner.nextInt();
        Student[] students = new Student[number];

        for (int i = 0; i < number; i++) {
            System.out.println("Введіть дані для студента " + (i + 1) + ":");
            System.out.print("ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Очистити буфер введення

            System.out.print("Прізвище: ");
            String surname = scanner.nextLine();

            System.out.print("Ім'я: ");
            String firstName = scanner.nextLine();

            System.out.print("По батькові: ");
            String patName = scanner.nextLine();

            System.out.print("Дата народження \n");
            System.out.print("День: ");
            int day = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Місяць: ");
            int month = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Рік: ");
            int year = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Адреса: ");
            String address = scanner.nextLine();

            System.out.print("Телефон: ");
            long phoneNumber = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Факультет: ");
            String faculty = scanner.nextLine();

            System.out.print("Курс: ");
            int course = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Група: ");
            String group = scanner.nextLine();

            // Створюємо новий об'єкт Student і додаємо його до масиву
            students[i] = new Student(id, surname, firstName, patName, day,
                    month, year, address, phoneNumber, faculty, course, group);
        }
        printStudentList(students);

        System.out.print("Введіть факультет для пошуку: ");
        String desiredFaculty = scanner.nextLine();
        Student[] foundStudents = searchFaculty(students, desiredFaculty);

        printRes(foundStudents);

        System.out.print("Введіть рік народження для пошуку студентів: ");
        int desiredBirthYear = scanner.nextInt();
        scanner.nextLine(); // Очистити буфер введення

        Student[] foundStudents3 = searchBirthYear(students, desiredBirthYear);
        printRes(foundStudents3);

        System.out.print("Введіть групу для пошуку: ");
        String desiredGroup = scanner.nextLine();
        Student[] foundStudents2 = searchGroup(students, desiredGroup);

        printRes(foundStudents2);

    }

    public static void printRes(Student[] foundStudents){
        if (foundStudents.length == 0) {
            System.out.println("Немає студентів за заданим запитом");
        } else {
            System.out.println("Студенти: ");
            for(Student student : foundStudents) {
                System.out.println(student.getSurname() + " " + student.getFirstName ());
            }
        }
    }

    public static void printStudentList(Student[] students) {
        System.out.println("Список студентів:");
        for (Student student : students) {
            System.out.println(student); // Викликаємо метод toString() для кожного об'єкта Student
        }
    }

    public static Student[] searchFaculty(Student[] students, String desiredFaculty){
        List<Student> foundStudents = new ArrayList<>();

        for (Student student : students){
            if (student.getFaculty().equals(desiredFaculty)) {
                foundStudents.add(student);
            }
        }
        return foundStudents.toArray(new Student[0]);
    }

    public static Student[] searchBirthYear(Student[] students, int desiredYear){
        List<Student> foundStudents = new ArrayList<>();

        for (Student student : students){
            if (student.getBirthYear() > desiredYear) {
                foundStudents.add(student);
            }
        }
       // Student[] foundStudentsArray = foundStudents.toArray(new Student[0]);
        //return foundStudentsArray;
        return foundStudents.toArray(new Student[0]);
    }

    public static Student[] searchGroup(Student[] students, String desiredGroup){
        List<Student> foundStudents = new ArrayList<>();

        for (Student student : students){
            if (student.getGroup().equals(desiredGroup)) {
                foundStudents.add(student);
            }
        }

        return foundStudents.toArray(new Student[0]);
    }
}
